import numpy as np
import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func
from flask import Flask, jsonify
from sqlalchemy import Table
from sqlalchemy import desc
from sqlalchemy import func
from datetime import timedelta, datetime


app = Flask(__name__)
#################################################
# Flask Routes
#################################################
#############################   home    ###############
@app.route("/")                                 
def welcome():
    return (
        f"Welcome to the Weather application API!<br/>"
        f"Available Routes:<br/>"
        f"/api/v1.0/stations<br/>"      #works
        f"/api/v1.0/precipitation<br/>"     #works
        f"/api/v1.0/tobs<br/>"          #works for all dates
        f"/api/v1.0/&#60;start><br/>"       #works but does not filter by date
        f"/api/v1.0/&#60;start>/&#60;end><br/>"     #does not work
        )
############################## ROUTE 1:         precipitation: works!!!!!         #####################
@app.route("/api/v1.0/precipitation")           
def precipitation():
    Base = automap_base()
    engine = create_engine("sqlite:///Resources/hawaii.sqlite", echo=False)
    Base.prepare(engine, reflect=True)
    conn = engine.connect()
    session = Session(engine)
    """Return the json of date and precipitation for the most active"""
    Measurement = Base.classes.measurement

    station_activity = session.query(Measurement.station,func.count(Measurement.station).label('activity')).\
    group_by(Measurement.station).order_by(desc('activity'))
    most_active = station_activity[0].station
    print(most_active)
    measure_all = session.query(Measurement.date, Measurement.prcp).filter(Measurement.station == most_active).all()
    
    measure_list = []
    for measure in measure_all:
        measure_dict = {}
        measure_dict["date"] = measure.date
        measure_dict["prcp"] = measure.prcp
        measure_list.append(measure_dict)
    return jsonify(measure_list)

##############################      ROUTE 2:    stations: works!!!         #####################
@app.route("/api/v1.0/stations")                                
def stations():
    Base = automap_base()
    engine = create_engine("sqlite:///Resources/hawaii.sqlite", echo=False)
    Base.prepare(engine, reflect=True)
    conn = engine.connect()
    session = Session(engine)
    Stations = Base.classes.station
    stations_query = session.query(Stations.station,Stations.name).all()
    return jsonify(stations_query)

    ##############################       REOUTE 3:   tobs     this works for most active station       #####################
@app.route("/api/v1.0/tobs")                    
def tobs():
    Base = automap_base()
    engine = create_engine("sqlite:///Resources/hawaii.sqlite", echo=False)
    Base.prepare(engine, reflect=True)
    conn = engine.connect()
    session = Session(engine)
    
    Measurement = Base.classes.measurement 
        
    station_activity = session.query(Measurement.station,func.count(Measurement.station).label('activity')).\
    group_by(Measurement.station).order_by(desc('activity'))
    most_active = station_activity[0].station
   
    measure_all = session.query(Measurement.date, Measurement.tobs).filter(Measurement.station == most_active).all()
    
    measure_list = []
    for measure in measure_all:
        measure_dict = {}
        measure_dict["date"] = measure.date
        measure_dict["tobs"] = measure.tobs
        measure_list.append(measure_dict)
    return jsonify(measure_list)

##############################         start date   this runs but does not filter for dates!!!         #####################
@app.route("/api/v1.0/<start_date>")                    
def start(start_date):
    Base = automap_base()
    engine = create_engine("sqlite:///Resources/hawaii.sqlite", echo=False)
    Base.prepare(engine, reflect=True)
    conn = engine.connect()
    session = Session(engine)
    Measurement = Base.classes.measurement 
    
    measure_all = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max( Measurement.tobs)).\
        filter(Measurement.date > str(start_date)).all()  
   
    return jsonify(measure_all)    

#######################################    start date to end date  - does not work  ##################################
@app.route("/api/v1.0/<start>/<end>")                
#def date_from_to(start, end):
#     print (start)
#     print(end)
#     import pendulum
#     Base = automap_base()
#     engine = create_engine("sqlite:///Resources/hawaii.sqlite", echo=False)
#     Base.prepare(engine, reflect=True)
#     conn = engine.connect()
#     session = Session(engine)
    
#     Measurement = Base.classes.measurement
    
#     # s_mon=parser.parse(start).month
#     # e_mon=parser.parse(end).month
#     # s_day=parser.parse(start).day
#     # e_day=parser.parse(end).day
#     # s_year=parser.parse(start).year
#     # e_year=parser.parse(end).year

#     # d1=date(s_year,s_mon,s_day)
#     # d2=date(e_year,e_mon,e_day)    
#     d1 = pendulum.parse(start, strict=False)
#     d2 = pendulum.parse(end, strict = False)
    
# # Set the start and end date of the trip
#     measure_query = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs), func.max(Measurement.tobs)).\
#         filter(pendulum.parce(Measurement.date,strict=False)>= d1).filter(pendulum.parce(Measurement.date, strict=False)<= d2).all()

# @app.route("/api/v1.0/justice-league/<real_name>")
# def justice_league_character(real_name):
#     """Fetch the Justice League character whose real_name matches
#        the path variable supplied by the user, or a 404 if not."""

#     canonicalized = real_name.replace(" ", "").lower()
#     for character in justice_league_members:
#         search_term = character["real_name"].replace(" ", "").lower()

#         if search_term == canonicalized:
#             return jsonify(character)

    #return jsonify({"error": f"Character with real_name {real_name} not found."}), 404


if __name__ == "__main__":
    app.run(debug=True)




